package pl.edu.wszib.springtalkingwithworld.model.AnimalShelter;

public class AnimalDTO {
    public String name;
    public int age;
    public AnimalType animalType;
    public AnimalGender animalGender;


}
