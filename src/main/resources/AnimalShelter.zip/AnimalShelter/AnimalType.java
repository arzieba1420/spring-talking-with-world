package pl.edu.wszib.springtalkingwithworld.model.AnimalShelter;

public enum AnimalType {
    CAT,
    DOG,
    FOX,
    RACCON
}
