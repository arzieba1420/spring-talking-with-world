package pl.edu.wszib.springtalkingwithworld.model.AnimalShelter;

public enum AnimalGender {
    F,
    M

}
