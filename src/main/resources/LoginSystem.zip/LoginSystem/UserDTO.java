package pl.edu.wszib.springtalkingwithworld.model.LoginSystem;

public class UserDTO {
    public String login;
    public String password;
    public String confirm;
}
