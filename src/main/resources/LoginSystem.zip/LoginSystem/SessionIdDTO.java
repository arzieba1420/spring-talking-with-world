package pl.edu.wszib.springtalkingwithworld.model.LoginSystem;

public class SessionIdDTO {

    public String sessionID;
}
